# BIA_IMAGING

**Target**: [01_target_BIA.xlsx](./01_target_BIA.xlsx)

Description: Imaging metadata template for submission to  BioImage Archive 

Source: ftp://ftp.biostudies.ebi.ac.uk/biostudies/nfs/BioImaging/templates/ (Metadata requirements as described on the webpage of BioImage Archive and from the submission webform were added)
Date: 14.10.2021

Submission to the BioImage Archive uses the BioStudies submission system (https://www.ebi.ac.uk/biostudies/submissions/#/signup). Either a submission form can be manually filled in with study data or study data can be automatically extracted from a selected pre-formatted file. In both cases additionally a “table of contents” for the image files, called “File List” should be additionally provided. It can be a tab delimited file (in which case file extension should be “.tsv”), or an Excel file (“.xls” or “.xlsx”). The first line is a header line, and the first cell has to contain word “Files”. Headers for the other columns are not predefined.

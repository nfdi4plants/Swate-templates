
# Genomics_NCBI_Genbank

01_target.xlsx  
- Description: Assay level template for batch upload at GenBank
- Source: https://submit.ncbi.nlm.nih.gov/submit/static_sp/wgs_batch/templates/Template_GenomeBatch.11700383121d.xlsx


# GenBank

Genomes Submission Guide https://www.ncbi.nlm.nih.gov/genbank/genomesubmit/

- submit via the submission portal: https://submit.ncbi.nlm.nih.gov/subs/genome/
- Make contact with NCBI regarding possible upload of a metadata sheet via FTP server?


### Genome Assembly Metadata

- Assembly method : Name of the assembly algorithm(s)
- Assembly method version or date : version of the algorithm or date it was run
- Genome coverage : The estimated base coverage across the genome, eg 12x.
- Sequencing technology : sequencing platform(s) used
- Assembly date : Optional. Year, month or day the assembly was made. Date formats: YYYY-MM-DD; YYYY-MM; YYYY
- Assembly name : Optional and not usually relevant for prokaryotes. This is a short name suitable for display that does not include the organism name eg, LoxAfr_3.0 for a Loxodonta africana assembly, version 3.0
- Full or Partial Genome in the sample : the answer is nearly always "yes, Full". Choose "no, partial" only if a subset of the sample was deliberately selected, eg just exomes or a single chromosome of a eukaryote or only the non-repetitive regions of the genome
- Reference genome : If this is NOT a de novo assembly, you will need to provide the accession.version and/or the assembly name of the genome assembly that was used as the reference guide for this assembly
- Update : accession of the genome being updated, when appropriate


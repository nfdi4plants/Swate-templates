# GEO_Microarray

### First Target 

Agilent (Two-color experiment) 

[01a_target_GEO_Agilent_two_color_matrix.xlsx](01a_target_GEO_Agilent_two_color_matrix.xls)

Description: "NCBI-GEO metadata spreadsheet for submission of Microarray data using two-color Agilent arrays"
Source: Sheet "METADATA TEMPLATE" from GA_Agilent_two_color_matrix.xlsx, https://www.ncbi.nlm.nih.gov/geo/info/geo_agil.html
Date: 30.07.2021

Agilent (One-color experiment) 

[01b_target_GEO_Agilent_one_color_matrix.xls](01b_target_GEO_Agilent_one_color_matrix.xls)

Description: "NCBI-GEO metadata spreadsheet for submission of Microarray data using two-color Agilent arrays"
Source: Sheet "METADATA TEMPLATE" from GA_Agilent_two_color_matrix.xlsx, https://www.ncbi.nlm.nih.gov/geo/info/geo_agil.html
Date: 30.09.2021

# SWATE templates - Working directory

This is the working directory to collect background info about endpoint repositories and organize SWATE templates (https://github.com/nfdi4plants/SWATE_templates)

# Overview of the current progress

[OneDrive](https://1drv.ms/u/s!AkQE1aGLuzxpgRJlEyMohWUgnN1v?e=XGwXbN)
- backups are stored [here](_backups)

# Naming convention

[ER-ID]_[Bioassay]




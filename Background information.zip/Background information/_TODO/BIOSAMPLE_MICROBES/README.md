
## NCBI packages (i.e. intepretations of MIxS packages?!) 

Source: https://submit.ncbi.nlm.nih.gov/biosample/template/







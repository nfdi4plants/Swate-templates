


# MAGE-TABv1.1_2011_07_28.pdf

## Source: http://fged.org/site_media/pdf/MAGE-TABv1.1_2011_07_28.pdf
## Desc.: MAGE-TAB specification. MIAME/MINSEQE compliant communication standard 


# MINSEQE_1.0.pdf






# MIxS standards 

MIxS: "Minimum Information about any (x) Sequence"
GSC: genomic standards consortium
Source: https://gensc.org/mixs/


NOTE: RDM-Collaboration FZJ (Use Case: Biotechnology)

Source:https://submit.ncbi.nlm.nih.gov/biosample/template/


# IDR_IMAGING

**Target**: [01_target_IDR.xlsx](./01_target_IDR.xlsx)\
Description: Imaging metadata template for submission to the the Image Data Resource (IDR)
Source for example templates: https://github.com/IDR/idr0000-lastname-example/archive/master.zip 
Date: 14.10.2021 


There are template files for two different use cases:
1. Templates for high content screens (HCS), or imaging studies performed in plates (e.g. 96 or 384 well plates) 
2. Templates for non-screen datasets, or studies which group images into a number of distinct experiments


For both types of study three files should be submitted lying together with the imaging data in a predefined folder structure: 
1. Study file - describing the overall study and the screens or experiments that were performed
2. Library (screens) or assay files (non-screens). For HCS the library file describes the plate layout of each screen. If more than one screen is performed as part of the study there should be a library file for each screen. For non-screen datasets, the assay file(s) describes each imaging experiment included in the study. 
3. Processed data files - containing summary results and/or a ‘hit' list for each screen or experiment. It may include phenotypes observed. 



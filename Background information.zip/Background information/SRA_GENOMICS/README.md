
# SRA

01a_target.xlsx  
- Description: Assay level template for SRA  
- Source: https://ftp-trace.ncbi.nlm.nih.gov/sra/metadata_table/SRA_metadata.xlsx  

- Before submitting an assembled genome, the raw sequence data (FASTQ) should be submitted to SRA
- During SRA submission you can automatically create a BioProject and BioSample 
- It is also possible to first submit a BioProject and BioSample


### Submit a single genome

```comment
The “Batch/multiple genomes” submission route seems to fit better to the ISA:ARC approach, you can just pre-fill the tab-delim. table and upload it, but:
The info below should be enquired by ISA-format templates, including e.g. the panels “Gaps” (Ns, linkage, etc.) and “Genome Info” (full genome, final version, PGAP, etc.)
```


This is the simplest submission route because you just fill in a web form in the Submission Portal and upload fasta (or sqn) files of the genome sequences. You will need to:

- Provide the BioProject created for this research effort, e.g., during submission of the reads to SRA OR register a new BioProject during the genome submission.
- Provide the BioSample created during submission of the reads to SRA OR register a BioSample during the genome submission
- Assert whether this is a WGS or non-wgs genome assembly
- Upload fasta sequences of the genome (or .sqn, file if the genome is annotated)
- Upload optional AGP file(s) to assemble scaffolds (unplaced or unlocalized) and/or chromosomes from the submitted sequences. This is for WGS only. Remember that you can submit  the gapped scaffolds themselves instead of submitting contigs plus an AGP file
- Provide information in response to prompts during the genome submission (see the common metada section):

1) Genome Assembly Data and other information about this genome assembly
2) Gap Information (What the Ns represent)
3) Chromosome and plasmid assignments. Every sequence in a non-wgs genome must have a chromosome or plasmid assignment and every chromosome must be submitted as a single sequence.
4) Authors and a title (for fasta submissions)
5) Release date (immediately after processing OR a specific date. Release will be on that date or upon publication, whichever is first)
6) Optional request for annotation of prokaryotic genomes by PGAP


---
Reviewer: Angela (@AngelaKranz)

---

# Readme review

## General comments

  - Keep in mind that there also other data types that can be uploaded to GEO/ArrayExpress (to reach as many users as possible every kind of template should be available) =>different kind of isolation/library preparation methods etc. => check if this requires more terms or separate templates (ChIP-Seq, Ribo-Seq, TSS, Microarrays)

> Agreed, the current template is only applicable to RNASeq data submission to GEO

  - Split progress according to final SWATE Templates to allow easier revision and comparison of progress and SWATE

> Agreed. 

  - Column headers in progress should match final term choice in SWATE Template

> Good point! 

  - Decision making progress: seq template for GEO is not specific regarding terms (method, kit etc.) that need to be included. How was decided which term is required? (e.g., for extraction protocol, library construction protocol, data processing…)


- Were plant-related terms checked against MIAPPE?

> No they weren't. 

## File 

02a_progress_review.xlsx

  -Added columns are red



---- 

## Additional responses to review: 

### 3ASY01_RNASeq.xlsx
- rRNA depletion -> library selection? 
- `Data File Name`is ISA wording for raw data file name 


### 4COM01_RNASeq.xlsx
- Missing col `Processing software`: "Not specifically, but somehow yes, because GEO expects that the user uploads processed data"
> This should be covered by the block `data processing pipeline`



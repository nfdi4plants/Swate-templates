# GEO_RNASEQ

### Target 

[01_target_GEO.xlsx](01_target_GEO.xlsx)

Description: "NCBI-GEO metadata spreadsheet for submission of high-throughput sequencing data
Source: Sheet "METADATA TEMPLATE" from seq_template.xlsx, https://www.ncbi.nlm.nih.gov/geo/info/examples/seq_template.xlsx
Date: 28.04.2020

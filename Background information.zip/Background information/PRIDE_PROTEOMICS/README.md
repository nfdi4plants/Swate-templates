# PRIDE_PROTEOMICS

### Target 

File 01_target_PRIDE.xlsx
Description: tabular version of an example output (submission.px) from proteoexchange wizard
Source
Date


### Submission guidelines

File: Submission_Summary_File_Format.pdf
Description:  
Source: http://www.proteomexchange.org/docs/Submission_Summary_File_Format.pdf  
Date: 14.07.2021. 


File: Submission_Tutorial.pdf. 
Description:  
Source: https://www.ebi.ac.uk/pride/markdown/submitdatapage/files/Submission_Tutorial.pdf  
Date: 14.07.2021  



### Compiles SWATE Templates

### Mapping



# Metabolomics_MetaboLights

### Target 

- 08.03.2021
- submission details: https://www.ebi.ac.uk/metabolights/guides/Quick_start_Guide/


### Mapping

- MetaboLights is based on and should directly work with ISA
- However, the MetaboLights ISA files have a very controlled vocabulary which -as far as I can see- is not available as an ontology. 
- e.g. https://www.ebi.ac.uk/metabolights/guides/Assay/GC_MS%20Assay
- So we still need to map between NFDI ontology and the Metabolights CV


---- 
## Specialties 

### Metabolite assignment file

- `MAF` = "metabolite assignment file"
- describes (part of) the data processing / extraction
- is connected to / validated against assay / study descriptors


### Validations
- For each piece of raw, processed and metadata, there are some validations to pass


### Default protocol sections (https://www.ebi.ac.uk/metabolights/guides/Protocol/Protocol)

1. Sample collection  --> 1SPL
2. Extraction --> 2EXT
3. Chromatography --> 3ASY
4. Mass spectrometry  --> 3ASY
5. Data transformation  --> 4COM
6. Metabolite identification --> 4COM
 

### Accepted file formats for raw data

- Derived file formats: mzml, nmrml, mzxml, xml, mzdata, cef, cnx, peakml, xy, smp, scan 
- Raw file formats: d, raw, idb, cdf, wiff, scan, dat, cmp, cdf.cmp, lcd, abf, jpf, xps, mgf



### Notes during upload to metabolights (02.09.2021, DB)

> Uploaded ISA Investigation file (i_Investigation.txt) will not be automatically synced with your study, contact us metabolights-help@ebi.ac.uk for help.

So, metabolights does not read from the investigation file provided via ftp / aspera. 
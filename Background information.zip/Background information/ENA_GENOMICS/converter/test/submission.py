import subprocess
result = subprocess.run(['curl', 
                         '-u', 
                         'Webin-60802:EiZ6VR4H7FzaZDL', 
                         '-F' ,
                         "SUBMISSION=@submission.xml", 
                         '-F', 
						 "PROJECT=@study.xml", 
                         "https://wwwdev.ebi.ac.uk/ena/submit/drop-box/submit/"], stdout=subprocess.PIPE)
result.stdout